s1 =input("Enter first string :")
s2 =input("Enter second string :")
sorted_s1=sorted(s1)
sorted_s2=sorted(s2)
if(sorted(s1)== sorted(s2)):
    print( s1,s2 ,"are anagram")
else:
    print("The strings aren't anagrams.")    
    