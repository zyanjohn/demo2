from django.contrib import admin

# Register your models here.
from.models import teacher

class teachers_display(admin.ModelAdmin):
    list_display=['name','email','image']
admin.site.register(teacher,teachers_display)