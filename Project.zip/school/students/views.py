from django.shortcuts import render
from django.http import HttpResponse
from.models import teacher
# Create your views here.
def index(request):
    # return HttpResponse('<h1>Welcome</h1>')
    tea=teacher.objects.all()
    return render(request,'index.html',{'tea':tea})
def about(request):
    return HttpResponse('<h1>This is about page</h1>')
def name(request):
    return HttpResponse('<h1>List your name</h1>')