from django.db import models

# Create your models here.
class teacher(models.Model):
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=100)
    image=models.CharField(max_length=3000)